"""Thresholds and value ranges. Defaults equal the business_rules.csv written by the generator."""
import csv

DEFAULT_RULES = {
    "idle_speed_threshold_kmh": 2.0,
    "idle_minutes_threshold": 5.0,
    "speeding_tolerance_kmh": 5.0,
    "gps_accuracy_max_meters": 50.0,
    "deviation_consecutive_readings": 3.0,
    "gps_jump_max_kmh": 200.0,
    "speed_max_kmh": 130.0,
    "engine_rpm_max": 4000.0,
    "engine_temperature_max_c": 130.0,
    "cargo_temperature_valid_min_c": -40.0,
    "cargo_temperature_valid_max_c": 60.0,
    "temperature_spike_c": 8.0,
    "flatline_readings": 20.0,
    "future_timestamp_tolerance_minutes": 5.0,
    "expected_interval_gps_sec": 10.0,
    "expected_interval_engine_sec": 10.0,
    "expected_interval_fuel_sec": 60.0,
    "expected_interval_temp_sec": 30.0,
    "offline_missed_intervals": 3.0,
    "late_data_watermark_minutes": 10.0,
    "sequence_gap_grace_minutes": 120.0,
    "dq_window_minutes": 10.0,
    "invalid_rate_alert_pct": 2.0,
    "quality_gate_max_invalid_pct": 5.0,
    "score_weight_speeding": 35.0,
    "score_weight_idling": 30.0,
    "score_weight_deviation": 20.0,
    "score_weight_lateness": 15.0,
    "score_limit_speeding_pct": 5.0,
    "score_limit_idling_pct": 10.0,
    "score_limit_deviation_episodes": 2.0,
    "score_limit_late_minutes": 60.0,
}


def load_rules(source=None):
    """Rules as a dict. `source` can be a path to business_rules.csv or a dict of overrides.
    Anything not given keeps its default, so the code never fails on a missing rule."""
    rules = dict(DEFAULT_RULES)
    if source is None:
        return rules
    if isinstance(source, dict):
        rules.update({k: float(v) for k, v in source.items()})
        return rules
    with open(source, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            rules[row["rule_name"].strip()] = float(row["rule_value"])
    return rules
