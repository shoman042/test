"""Message schema v1 (sections 4.1 to 4.6 of the guide)."""

SCHEMA_VERSION = 1
SUPPORTED_SCHEMA_VERSIONS = (1,)
SIGNAL_TYPES = ("gps", "engine", "fuel", "temperature", "device_status")

# (field name, type). Types: string, int, long, double, boolean, timestamp
COMMON_FIELDS = [
    ("schema_version", "int"), ("signal_type", "string"), ("event_id", "string"), ("vehicle_id", "string"),
    ("trip_id", "string"), ("device_id", "string"), ("event_time", "timestamp"), ("sequence_number", "long"),
]

SIGNAL_FIELDS = {
    "gps": [("latitude", "double"), ("longitude", "double"), ("speed_kmh", "double"),
            ("heading_degrees", "double"), ("gps_accuracy_meters", "double")],
    "engine": [("engine_on", "boolean"), ("engine_rpm", "int"), ("engine_temperature_c", "double"),
               ("vehicle_speed_kmh", "double"), ("battery_voltage_v", "double")],
    "fuel": [("fuel_level_liters", "double"), ("trip_fuel_used_liters", "double"), ("odometer_km", "double"),
             ("is_refueling", "boolean")],
    "temperature": [("shipment_id", "string"), ("sensor_id", "string"), ("temperature_value", "double"),
                    ("temperature_unit", "string"), ("setpoint_temperature_c", "double"),
                    ("sensor_status", "string")],
    "device_status": [("event_type", "string"), ("offline_from", "timestamp"), ("reconnected_at", "timestamp"),
                      ("stored_gps", "int"), ("stored_engine", "int"), ("stored_fuel", "int"),
                      ("stored_temperature", "int"), ("dropped_messages", "int"), ("upload_method", "string"),
                      ("upload_id", "string")],
}

# fields that may be null (everything else is required)
NULLABLE_FIELDS = {"temperature_value", "upload_id"}

_SPARK = {"string": "StringType", "int": "IntegerType", "long": "LongType", "double": "DoubleType",
          "boolean": "BooleanType", "timestamp": "TimestampType"}


def required_fields(signal_type):
    """Field names that must be present (and not null) for a signal type."""
    names = [n for n, _ in COMMON_FIELDS + SIGNAL_FIELDS[signal_type]]
    return [n for n in names if n not in NULLABLE_FIELDS]


def spark_schema(signal_type):
    """pyspark StructType for a signal (imports pyspark only when called)."""
    from pyspark.sql import types as T
    fields = [T.StructField(n, getattr(T, _SPARK[t])(), True) for n, t in COMMON_FIELDS + SIGNAL_FIELDS[signal_type]]
    return T.StructType(fields)
