"""Deduplication keys and the winning-copy rule (section 6.5 of the guide).

DEDUP_KEY            exact duplicate: the same event_id twice (also the Silver MERGE key).
NEAR_DUPLICATE_KEY   same vehicle, signal and time but a NEW event_id.

Winning-copy rule (documented, deterministic): keep the copy that ARRIVED first (smallest arrival_time);
if arrival times tie or are missing, keep the smaller event_id.
"""

DEDUP_KEY = ("event_id",)
NEAR_DUPLICATE_KEY = ("vehicle_id", "signal_type", "event_time")


def near_duplicate_key(record):
    return tuple(record.get(k) for k in NEAR_DUPLICATE_KEY)


def _rank(record):
    arrival = record.get("arrival_time")
    return (str(arrival) if arrival is not None else "9999", str(record.get("event_id", "")))


def winning_copy(a, b):
    """Return the record that wins between two copies of the same event."""
    return a if _rank(a) <= _rank(b) else b


def deduplicate(records):
    """Pure-python reference implementation. Returns (kept, exact_removed, near_removed)."""
    by_id, exact = {}, 0
    for r in records:
        k = r.get("event_id")
        if k in by_id:
            exact += 1
            by_id[k] = winning_copy(by_id[k], r)
        else:
            by_id[k] = r
    by_key, near = {}, 0
    for r in by_id.values():
        k = near_duplicate_key(r)
        if k in by_key:
            near += 1
            by_key[k] = winning_copy(by_key[k], r)
        else:
            by_key[k] = r
    return list(by_key.values()), exact, near
