"""Fleet Telematics shared library.

One place for the rules that BOTH the streaming job and the batch jobs apply, so they can never disagree:
  schema      message layout (schema version 1)
  rules       thresholds / value ranges (defaults = business_rules.csv written by the generator)
  validation  validate_message(): PARSE_ERROR, MISSING_REQUIRED_FIELD, TYPE_MISMATCH, OUT_OF_RANGE, ...
  dedup       deduplication keys and the winning-copy rule
  geo         distances (route deviation, GPS jump)
"""
from .schema import (SCHEMA_VERSION, SUPPORTED_SCHEMA_VERSIONS, SIGNAL_TYPES, COMMON_FIELDS, SIGNAL_FIELDS,
                     required_fields, spark_schema)
from .rules import DEFAULT_RULES, load_rules
from .validation import (ValidationResult, validate_message, temperature_spike, is_flatline, impossible_gps_jump,
                         ERROR_CODES, FLAGS)
from .dedup import DEDUP_KEY, NEAR_DUPLICATE_KEY, near_duplicate_key, winning_copy, deduplicate
from .geo import haversine_km, distance_to_polyline_m

__version__ = "1.0.0"
__all__ = [
    "SCHEMA_VERSION", "SUPPORTED_SCHEMA_VERSIONS", "SIGNAL_TYPES", "COMMON_FIELDS", "SIGNAL_FIELDS",
    "required_fields", "spark_schema", "DEFAULT_RULES", "load_rules", "ValidationResult", "validate_message",
    "temperature_spike", "is_flatline", "impossible_gps_jump", "ERROR_CODES", "FLAGS", "DEDUP_KEY",
    "NEAR_DUPLICATE_KEY", "near_duplicate_key", "winning_copy", "deduplicate", "haversine_km",
    "distance_to_polyline_m", "__version__",
]
