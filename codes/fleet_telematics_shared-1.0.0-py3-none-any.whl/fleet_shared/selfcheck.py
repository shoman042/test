"""python -m fleet_shared.selfcheck messages.jsonl [business_rules.csv]
Validates every line of a file of raw messages and prints the counts by error code and flag."""
import sys
from collections import Counter

from .rules import load_rules
from .validation import validate_message


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        sys.exit("usage: python -m fleet_shared.selfcheck messages.jsonl [business_rules.csv]")
    rules = load_rules(argv[1] if len(argv) > 1 else None)
    ok, errors, flags = 0, Counter(), Counter()
    with open(argv[0], encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            r = validate_message(line, rules)
            if r.ok:
                ok += 1
                flags.update(r.flags)
            else:
                errors[r.error_code] += 1
    total = ok + sum(errors.values())
    print(f"messages={total} valid={ok} invalid={sum(errors.values())}")
    print("errors:", dict(errors))
    print("flags:", dict(flags))


if __name__ == "__main__":
    main()
