"""validate_message(): the single validation used by the real-time job and by Batch job 1.

Quarantine a record that cannot be trusted or interpreted (ok = False, error_code set).
Keep and flag a record that is usable but suspicious (ok = True, flags set).
"""
import json
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from .geo import haversine_km
from .rules import load_rules
from .schema import (COMMON_FIELDS, NULLABLE_FIELDS, SIGNAL_FIELDS, SIGNAL_TYPES, SUPPORTED_SCHEMA_VERSIONS,
                     required_fields)

ERROR_CODES = ("PARSE_ERROR", "MISSING_REQUIRED_FIELD", "TYPE_MISMATCH", "OUT_OF_RANGE", "INVALID_GPS",
               "INVALID_TIMESTAMP", "UNKNOWN_VEHICLE", "UNKNOWN_TRIP", "UNKNOWN_SIGNAL_TYPE", "SCHEMA_DRIFT")
FLAGS = ("UNIT_CONVERTED", "SENSOR_NULL", "SENSOR_FAULT", "LOW_ACCURACY", "SCHEMA_DRIFT", "SPIKE", "FLATLINE",
         "IMPOSSIBLE_JUMP")
RETRYABLE = {"UNKNOWN_VEHICLE", "UNKNOWN_TRIP"}   # reference data may arrive later


@dataclass
class ValidationResult:
    ok: bool
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    flags: List[str] = field(default_factory=list)
    record: Optional[dict] = None
    retryable: bool = False

    def to_dict(self):
        return {"ok": self.ok, "error_code": self.error_code, "error_message": self.error_message,
                "flags": list(self.flags), "retryable": self.retryable}


def _fail(code, message):
    return ValidationResult(False, code, message, retryable=code in RETRYABLE)


def parse_timestamp(value):
    """ISO timestamp -> naive UTC datetime, or None."""
    if not isinstance(value, str) or len(value) < 10:
        return None
    s = value.strip().replace("Z", "+00:00")
    if " " in s and "T" not in s:
        s = s.replace(" ", "T", 1)
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        return None
    if d.tzinfo is not None:
        d = d.astimezone(timezone.utc).replace(tzinfo=None)
    return d


def _type_ok(value, typ):
    if typ in ("int", "long"):
        return isinstance(value, int) and not isinstance(value, bool)
    if typ == "double":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if typ == "boolean":
        return isinstance(value, bool)
    return isinstance(value, str)       # string and timestamp (parsed separately)


def validate_message(raw, rules=None, known_vehicles=None, known_trips=None, now=None, tank_capacity_by_vehicle=None):
    """Validate one raw message (the exact text received, or an already parsed dict).

    rules                    dict from load_rules(); defaults are used for anything missing.
    known_vehicles/known_trips  optional sets; unknown ids give UNKNOWN_VEHICLE / UNKNOWN_TRIP (retryable).
    now                      optional datetime (SIMULATED time) for the future-timestamp check.
    tank_capacity_by_vehicle optional {vehicle_id: litres}; a fuel level above capacity is OUT_OF_RANGE.
    """
    rules = load_rules(rules) if not isinstance(rules, dict) or "speed_max_kmh" not in rules else rules

    # ---- parse
    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="replace")
    if isinstance(raw, dict):
        msg = raw
    else:
        try:
            msg = json.loads(raw)
        except (TypeError, ValueError) as e:
            return _fail("PARSE_ERROR", f"not valid JSON: {e}")
        if not isinstance(msg, dict):
            return _fail("PARSE_ERROR", "payload is not a JSON object")

    # ---- signal type and schema version
    sig = msg.get("signal_type")
    if sig is None:
        return _fail("MISSING_REQUIRED_FIELD", "missing signal_type")
    if sig not in SIGNAL_TYPES:
        return _fail("UNKNOWN_SIGNAL_TYPE", f"unknown signal_type {sig!r}")
    ver = msg.get("schema_version")
    if ver is None:
        return _fail("MISSING_REQUIRED_FIELD", "missing schema_version")
    if not _type_ok(ver, "int"):
        return _fail("TYPE_MISMATCH", "schema_version must be an integer")
    if ver not in SUPPORTED_SCHEMA_VERSIONS:
        return _fail("SCHEMA_DRIFT", f"unsupported schema_version {ver}")

    # ---- required fields, then types
    missing = [f for f in required_fields(sig) if msg.get(f) is None or msg.get(f) == ""]
    if missing:
        return _fail("MISSING_REQUIRED_FIELD", "missing: " + ", ".join(missing))
    spec = COMMON_FIELDS + SIGNAL_FIELDS[sig]
    for name, typ in spec:
        v = msg.get(name)
        if v is None and name in NULLABLE_FIELDS:
            continue
        if not _type_ok(v, typ):
            return _fail("TYPE_MISMATCH", f"{name} should be {typ}, got {type(v).__name__}")
        if typ == "double" and not math.isfinite(v):
            return _fail("OUT_OF_RANGE", f"{name} is not a finite number")

    flags = []
    known = {n for n, _ in spec}
    if set(msg) - known:
        flags.append("SCHEMA_DRIFT")                # extra fields: compatible, keep and flag

    # ---- timestamps
    t = parse_timestamp(msg["event_time"])
    if t is None:
        return _fail("INVALID_TIMESTAMP", "event_time is not a valid timestamp")
    if now is not None and t > now + timedelta(minutes=rules["future_timestamp_tolerance_minutes"]):
        return _fail("INVALID_TIMESTAMP", "event_time is in the future")

    # ---- reference checks
    if known_vehicles is not None and msg["vehicle_id"] not in known_vehicles:
        return _fail("UNKNOWN_VEHICLE", f"vehicle {msg['vehicle_id']} not in reference data")
    if known_trips is not None and msg["trip_id"] not in known_trips:
        return _fail("UNKNOWN_TRIP", f"trip {msg['trip_id']} not in reference data")

    rec = dict(msg)

    # ---- signal specific
    if sig == "gps":
        lat, lon = msg["latitude"], msg["longitude"]
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            return _fail("INVALID_GPS", f"position out of range ({lat}, {lon})")
        if lat == 0 and lon == 0:
            return _fail("INVALID_GPS", "position is exactly (0, 0)")
        if not 0 <= msg["speed_kmh"] <= rules["speed_max_kmh"]:
            return _fail("OUT_OF_RANGE", f"speed_kmh {msg['speed_kmh']}")
        if not 0 <= msg["heading_degrees"] < 360:
            return _fail("OUT_OF_RANGE", f"heading_degrees {msg['heading_degrees']}")
        if msg["gps_accuracy_meters"] < 0:
            return _fail("OUT_OF_RANGE", "gps_accuracy_meters is negative")
        if msg["gps_accuracy_meters"] > rules["gps_accuracy_max_meters"]:
            flags.append("LOW_ACCURACY")             # kept, ignored for route deviation
    elif sig == "engine":
        if not 0 <= msg["engine_rpm"] <= rules["engine_rpm_max"]:
            return _fail("OUT_OF_RANGE", f"engine_rpm {msg['engine_rpm']}")
        if not -50 <= msg["engine_temperature_c"] <= rules["engine_temperature_max_c"]:
            return _fail("OUT_OF_RANGE", f"engine_temperature_c {msg['engine_temperature_c']}")
        if not 0 <= msg["vehicle_speed_kmh"] <= rules["speed_max_kmh"]:
            return _fail("OUT_OF_RANGE", f"vehicle_speed_kmh {msg['vehicle_speed_kmh']}")
        if not 0 <= msg["battery_voltage_v"] <= 40:
            return _fail("OUT_OF_RANGE", f"battery_voltage_v {msg['battery_voltage_v']}")
    elif sig == "fuel":
        for f in ("fuel_level_liters", "trip_fuel_used_liters", "odometer_km"):
            if msg[f] < 0:
                return _fail("OUT_OF_RANGE", f"{f} is negative")
        cap = (tank_capacity_by_vehicle or {}).get(msg["vehicle_id"])
        if cap is not None and msg["fuel_level_liters"] > cap * 1.05:
            return _fail("OUT_OF_RANGE", f"fuel_level_liters {msg['fuel_level_liters']} above tank capacity {cap}")
    elif sig == "temperature":
        if msg["temperature_unit"] not in ("C", "F"):
            return _fail("TYPE_MISMATCH", "temperature_unit must be C or F")
        if msg["sensor_status"] not in ("OK", "FAULT"):
            return _fail("TYPE_MISMATCH", "sensor_status must be OK or FAULT")
        value = msg.get("temperature_value")
        if value is None:
            flags.append("SENSOR_NULL")              # kept: the evidence of the fault is preserved
        else:
            if not _type_ok(value, "double") or not math.isfinite(value):
                return _fail("TYPE_MISMATCH", "temperature_value is not a number")
            if msg["temperature_unit"] == "F":
                value = round((value - 32) * 5 / 9, 2)
                rec["temperature_value"], rec["temperature_unit"] = value, "C"
                flags.append("UNIT_CONVERTED")
            if not rules["cargo_temperature_valid_min_c"] <= value <= rules["cargo_temperature_valid_max_c"]:
                return _fail("OUT_OF_RANGE", f"cargo temperature {value} C outside the plausible range")
        if msg["sensor_status"] == "FAULT":
            flags.append("SENSOR_FAULT")
    else:  # device_status
        if msg["event_type"] != "RECONNECTED":
            return _fail("TYPE_MISMATCH", "event_type must be RECONNECTED")
        if msg["upload_method"] not in ("STREAM_BURST", "BULK_FILE"):
            return _fail("TYPE_MISMATCH", "upload_method must be STREAM_BURST or BULK_FILE")
        for f in ("stored_gps", "stored_engine", "stored_fuel", "stored_temperature", "dropped_messages"):
            if msg[f] < 0:
                return _fail("OUT_OF_RANGE", f"{f} is negative")
        a, b = parse_timestamp(msg["offline_from"]), parse_timestamp(msg["reconnected_at"])
        if a is None or b is None or a > b:
            return _fail("INVALID_TIMESTAMP", "offline_from / reconnected_at invalid")

    rec["dq_flags"] = flags
    return ValidationResult(True, flags=flags, record=rec)


# ---- stateful checks: need the previous reading, so the caller (a window / state function) passes it in
def temperature_spike(prev_c, cur_c, rules=None):
    """True when consecutive cargo readings jump by more than temperature_spike_c."""
    r = rules or load_rules()
    return prev_c is not None and cur_c is not None and abs(cur_c - prev_c) > r["temperature_spike_c"]


def is_flatline(values, rules=None):
    """True when the last flatline_readings cargo readings are identical (stuck sensor)."""
    r = rules or load_rules()
    n = int(r["flatline_readings"])
    return len(values) >= n and len(set(values[-n:])) == 1


def impossible_gps_jump(prev, cur, rules=None):
    """prev/cur: dicts with latitude, longitude, event_time (ISO text). True when the implied speed is above gps_jump_max_kmh."""
    r = rules or load_rules()
    t0, t1 = parse_timestamp(prev["event_time"]), parse_timestamp(cur["event_time"])
    if t0 is None or t1 is None or t1 <= t0:
        return False
    hours = (t1 - t0).total_seconds() / 3600.0
    km = haversine_km(prev["latitude"], prev["longitude"], cur["latitude"], cur["longitude"])
    return km / hours > r["gps_jump_max_kmh"]
