"""Distances shared by route-deviation and GPS-jump checks."""
import math


def haversine_km(lat1, lon1, lat2, lon2):
    la1, lo1, la2, lo2 = map(math.radians, (lat1, lon1, lat2, lon2))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(h))


def distance_to_polyline_m(lat, lon, points):
    """Shortest distance in metres from a position to a route path.
    `points` = [(lat, lon), ...] ordered checkpoints of the route (planar approximation, fine for a few km)."""
    k = 111320.0
    cl = math.cos(math.radians(lat))
    px, py = lat * k, lon * k * cl
    best = float("inf")
    for (a, b), (c, d) in zip(points, points[1:]):
        ax, ay, bx, by = a * k, b * k * cl, c * k, d * k * cl
        dx, dy = bx - ax, by - ay
        length2 = dx * dx + dy * dy
        u = 0.0 if length2 == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / length2))
        best = min(best, math.hypot(px - ax - u * dx, py - ay - u * dy))
    return best
